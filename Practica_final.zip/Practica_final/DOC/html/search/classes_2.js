var searchData=
[
  ['info_5fprioridad_58',['info_prioridad',['../structAreaProcesos_1_1info__prioridad.html',1,'AreaProcesos']]]
];
