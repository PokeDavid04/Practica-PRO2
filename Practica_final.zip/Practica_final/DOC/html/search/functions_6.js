var searchData=
[
  ['procesador_96',['Procesador',['../classProcesador.html#aacfa2a06c7d44636ecfb0338bebbfa8b',1,'Procesador::Procesador()'],['../classProcesador.html#a23bd738c44774499b8d5287ebea8f452',1,'Procesador::Procesador(string id, int cmem)']]],
  ['proceso_97',['Proceso',['../classProceso.html#a632f57d6ec48e76c80fbeb7734c1148c',1,'Proceso::Proceso()'],['../classProceso.html#a50f82929a5a5b55fb84959fd65b97c23',1,'Proceso::Proceso(int id, int cmem, int t, string p)'],['../classProceso.html#ab3f6a863fac8c441b1cdc5d7bd06d937',1,'Proceso::Proceso(int cmem)']]]
];
