var searchData=
[
  ['cluster_75',['Cluster',['../classCluster.html#aee7feb1d599d4c8fda6c3ee83e86ba81',1,'Cluster']]],
  ['compactar_5fmemoria_76',['compactar_memoria',['../classCluster.html#a622839c3b8dc923dc36f6026f35db269',1,'Cluster::compactar_memoria()'],['../classProcesador.html#a06b0b1c913b359a1bc6c920120dd0e66',1,'Procesador::compactar_memoria()']]],
  ['compactar_5fmemoria_5fprocesador_77',['compactar_memoria_procesador',['../classCluster.html#a2c9460fedf7bfc5963302c6e33d001fe',1,'Cluster']]],
  ['consul_5fcabe_5fhueco_78',['consul_cabe_hueco',['../classProcesador.html#addbfd8cab7d75d5d16a9d830d4c0c709',1,'Procesador']]],
  ['consul_5fidentificador_79',['consul_identificador',['../classProceso.html#a30c8302b163d93a24def32ed154937bf',1,'Proceso']]],
  ['consul_5fmejor_5fhueco_80',['consul_mejor_hueco',['../classCluster.html#a709d19b6cc8e7c791227e0ec6914a427',1,'Cluster']]],
  ['consul_5fmemoria_81',['consul_memoria',['../classProceso.html#aad4d01b21237cf5ffe32032a044b1853',1,'Proceso']]],
  ['consul_5fprioridad_82',['consul_prioridad',['../classProceso.html#a01880c9fdefc97681c755ee295859b48',1,'Proceso']]],
  ['consul_5ftiempo_83',['consul_tiempo',['../classProceso.html#aacd519894341a2f351f0a5af8a7931f6',1,'Proceso']]]
];
