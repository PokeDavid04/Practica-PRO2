var searchData=
[
  ['i_5fcopiar_5fcluster_29',['i_copiar_cluster',['../classCluster.html#a5d28094b3449c80943e4a12f5d13690e',1,'Cluster']]],
  ['i_5fescribir_5festructura_30',['i_escribir_estructura',['../classCluster.html#a142ea2f57a6e339b3437d094a033718f',1,'Cluster']]],
  ['i_5fleer_31',['i_leer',['../classCluster.html#a33d37571ecf1f30ada4f50768391a038',1,'Cluster']]],
  ['identificador_32',['identificador',['../classProcesador.html#ac9edc7bbfe8bc9f673e8b1517232c84b',1,'Procesador::identificador()'],['../classProceso.html#a3418ac65a7c31135ed436bb38add64dc',1,'Proceso::identificador()']]],
  ['identificador_5fvacio_33',['IDENTIFICADOR_VACIO',['../classProcesador.html#af4160f35045aa1bfb6468f7ea7de16c1',1,'Procesador']]],
  ['info_5fprioridad_34',['info_prioridad',['../structAreaProcesos_1_1info__prioridad.html',1,'AreaProcesos']]]
];
