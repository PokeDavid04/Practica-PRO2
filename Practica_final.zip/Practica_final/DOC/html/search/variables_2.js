var searchData=
[
  ['identificador_103',['identificador',['../classProcesador.html#ac9edc7bbfe8bc9f673e8b1517232c84b',1,'Procesador::identificador()'],['../classProceso.html#a3418ac65a7c31135ed436bb38add64dc',1,'Proceso::identificador()']]],
  ['identificador_5fvacio_104',['IDENTIFICADOR_VACIO',['../classProcesador.html#af4160f35045aa1bfb6468f7ea7de16c1',1,'Procesador']]]
];
