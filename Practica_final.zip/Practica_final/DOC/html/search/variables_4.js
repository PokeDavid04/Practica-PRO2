var searchData=
[
  ['mapprocesos_107',['mapprocesos',['../classProcesador.html#ada69a81c89b3729cd0aea020491d255a',1,'Procesador']]],
  ['memoria_108',['memoria',['../classProceso.html#ac37ccb93a804abd4b829ac7d4ad828bd',1,'Proceso']]],
  ['memprocesos_109',['memprocesos',['../classProcesador.html#a517a05d934d61414548e8587f97fb478',1,'Procesador']]]
];
