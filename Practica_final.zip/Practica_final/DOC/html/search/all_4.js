var searchData=
[
  ['leer_35',['leer',['../classAreaProcesos.html#ada593073fe7bef4581cfe5cfb8c0eab6',1,'AreaProcesos::leer()'],['../classCluster.html#a482d879edb37f72e49c13e9c3e6c4320',1,'Cluster::leer()']]],
  ['listprocesadores_36',['listprocesadores',['../classCluster.html#a81d024209879707da0ac88dc00c1e17d',1,'Cluster']]],
  ['listprocesos_37',['listprocesos',['../structAreaProcesos_1_1info__prioridad.html#a86cba975bf0448e86562e60b18c6dd91',1,'AreaProcesos::info_prioridad']]]
];
