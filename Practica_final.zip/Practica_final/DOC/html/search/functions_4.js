var searchData=
[
  ['leer_94',['leer',['../classAreaProcesos.html#ada593073fe7bef4581cfe5cfb8c0eab6',1,'AreaProcesos::leer()'],['../classCluster.html#a482d879edb37f72e49c13e9c3e6c4320',1,'Cluster::leer()']]]
];
