/** @file Cluster.hh
    @brief Especificación de la clase Cluster
*/

#ifndef _CLUSTER_HH_
#define _CLUSTER_HH_

// #ifndef NO_DIAGRAM
#include "Proceso.hh"
#include "Procesador.hh"
#include "BinTree.hh"
#include <list>
using namespace std;
// #endif

/** @class Cluster
    @brief Representa un cluster con un arbol binario de procesadores

*/

class Cluster
{
public:
  //Constructoras
    /**
     * @name Constructoras
     * @{
    */

  /** @brief Creadora por defecto.

      Se ejecuta automáticamente al declarar un cluster.
      \pre <em>cierto</em>
      \post El resultado es un cluster sin procesadores
  */
  Cluster();
  /**@}*/



  //Modificadoras
  /**
     * @name Modificadoras
     * @{
    */

  /** @brief Añade un cluster en el lugar de un procesador

      \pre id es el identificador de un procesador del parámetro implícito y no tiene procesos en ejecución ni procesadores auxiliares
      \post El parámetro implícito pasa a tener el cluster c en lugar del procesador con el identificador id
  */
  void añadir_cluster(string id, Cluster &c);

  /** @brief Añade un proceso en un procesador concreto del parámetro implícito

      \pre Existe un procesador con identificador id donde cabe p
      \post El parámetro implícito tiene el proceso p en el procesador con identificador id
  */
  void añadir_proceso_procesador(string id, Proceso &p);

  /** @brief Elimina un proceso en un procesador concreto del parámetro implícito

      \pre Existe un procesador con identificador id donde se encuentra p
      \post El parámetro implícito ya no tiene el proceso p en el procesador con identificador id
  */
  void eliminar_proceso_procesador(string id, Proceso &p);

  /** @brief Añade un proceso al parámetro implícito

      Añade p en el procesador con el hueco que más se ajuste a la memoria que ocupa p, en caso de empate lo añade al que tenga mas memoria libre, en caso de empate, lo añade al más próximo a la raíz y en caso de empate al de más a la izquierda.
      \pre p cabe en algún procesador del parámetro implícito
      \post El parámetro implícito tiene el proceso p en algún procesador
  */
  void añadir_proceso(Proceso &p);

  /** @brief Modificadora de los procesos de los procesadores del parámetro implícito

      \pre <em>cierto</em>
      \post Avanza t unidades de tiempo en los procesos de cada procesador del parámetro implícito y elimina los procesos terminados
  */
  void avanzar_tiempo(int t);

  /** @brief Modificadora de los procesos de un procesador del parámetro implicito

      Reordena los procesos de un procesador por orden de llegada, lo mas a la izquierda posible y sin dejar huecos entre medio
      \pre <em>cierto</em>
      \post Reordena los procesos del procesador con identificador id del parámetro implícito
  */
  void compactar_memoria_procesador(string id);

  /** @brief Modificadora de los procesos de cada procesador del parámetro implicito

      Reordena los procesos de cada procesador por orden de llegada, lo mas a la izquierda posible y sin dejar huecos entre medio
      \pre <em>cierto</em>
      \post Reordena los procesos de cada procesador del parámetro implícito
  */
  void compactar_memoria();
  /**@}*/



  //Consultoras
  /**
     * @name Consultoras
     * @{
    */

  /** @brief Consulta si existe un procesador

      \pre <em>cierto</em>
      \post El resultado es true si se encuentra un procesador con identificador id en el parámetro implícito y false de lo contrario
  */
  bool existe_procesador(string id) const;

  /** @brief Consulta si existe un proceso en un procesador

      \pre <em>cierto</em>
      \post El resultado es true si hay un procesador con identificador id que contiene el proceso p en el parámetro implícito y false de lo contrario
  */
  bool existe_proceso_procesador(string id, Proceso &p) const;

  /** @brief Consulta si cabe un proceso en un procesador

      \pre <em>cierto</em>
      \post El resultado es true si el proceso p cabe en la memoria del procesador con identificador id del parámetro implícito y false de lo contrario
  */
  bool cabe_proceso_procesador(string id, Proceso &p) const;

  /** @brief Consulta si cabe un proceso en algun procesador

      \pre <em>cierto</em>
      \post El resultado es true si el proceso p cabe en la memoria de algún procesador con identificador id del parámetro implícito y false de lo contrario
  */
  bool cabe_proceso(Proceso &p) const;

  /** @brief Consulta un procesador

      \pre Existe un procesador con identificador id en el parámetro implícito
      \post El resultado es el procesador con identificador id
  */
  Procesador consul_procesador(string id) const;

  /** @brief Consulta los procesos con una prioridad

      \pre <em>cierto</em>
      \post El resultado es una lista con los procesos con prioridad p en los procesadores del parámtro implícito
  */
  list<Proceso> consul_procesos_prioridad(string id) const;

  /** @brief Consulta si tiene procesadores auxiliares

      \pre Existe un procesador con identificador id en el parámetro implícito
      \post El resultado es true el procesador con identificador id tiene procesadores auxiliares y false de lo contrario
  */
  bool tiene_procesadores_auxiliares(string id) const;
  /**@}*/



  /**
     * @name Lectura y Escritura
     * @{
    */
  //Lectura de cluster

  /** @brief Operación de lectura

      \pre <em>cierto</em>
      \post Se han leido los atributos del parámetro implícito desde el canal
      standard de entrada.
  */
  void leer();


  //Escritura de cluster

  /** @brief Operación de escritura

      \pre <em>cierto</em>
      \post Se han escrito los atributos del parámetro implícito en el canal
      standard de salida.
  */
  void escribir() const;

  /** @brief Operación de escritura de estructura

      \pre <em>cierto</em>
      \post Se han escrito la estructura del parámetro implícito en el canal
      standard de salida.
  */
  void escribir_estructura() const;
  /**@}*/

private:
BinTree<Procesador> clust;
};


#endif
