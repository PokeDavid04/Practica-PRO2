/** @file Proceso.hh
    @brief Especificación de la clase Proceso
*/

#ifndef _PROCESO_HH_
#define _PROCESO_HH_

// #ifndef NO_DIAGRAM
// #include "PRO2Excepcio.hh"
#include <iostream>
using namespace std;
// #endif

/** @class Proceso
    @brief Representa un proceso con identificador, cantidad de memoria que ocupa, tiempo de ejecución y prioridad

*/
class Proceso
{
public:
  //Constructoras
    /**
     * @name Constructoras
     * @{
    */

  /** @brief Creadora por defecto.

      Se ejecuta automáticamente al declarar un proceso.
      \pre <em>cierto</em>
      \post El resultado es un proceso sin identificador, cantidad de memoria, tiempo de ejecución ni prioridad
  */
  Proceso();

  /** @brief Creadora con valores concretos.

      \pre id>=0, cmem>0, t>0 y p un string de letras y dígitos
      \post El resultado es un proceso con identificador "id", cantidad de memoria "cmem", tiempo "t" y prioridad "p"
  */
  Proceso(int id, int cmem, int t, string p);
  /**@}*/



  //Modificadoras
  /**
     * @name Modificadoras
     * @{
    */

  /** @brief Modificadora del atributo tiempo

      \pre <em>cierto</em>
      \post El parámetro implícito pasa a tener tiempo -1
  */
  void avanzar_unidad_tiempo();
  /**@}*/



  //Consultoras
  /**
     * @name Consultoras
     * @{
    */

  /** @brief Consultora del identificador

      \pre <em>cierto</em>
      \post El resultado es el identificador del parámetro implícito
  */
  int consul_identificador() const;

  /** @brief Consultora de la cantidad de memoria
      \pre <em>cierto</em>
      \post El resultado es al memoria del parámetro implícito
  */
  int consul_memoria() const;

  /** @brief Consultora del tiempo de ejecución

      \pre <em>cierto</em>
      \post El resultado es el tiempo del parámetro implícito
  */
  int consul_tiempo() const;

  /** @brief Consultora de la prioridad

      \pre <em>cierto</em>
      \post El resultado es la prioridad del parámetro implícito
  */
  string consul_prioridad() const;
  /**@}*/



  /**
     * @name Lectura y Escritura
     * @{
    */
  //Lectura de proceso

  /** @brief Operación de lectura

      \pre <em>cierto</em>
      \post Se han leido los atributos del parámetro implícito desde el canal
      standard de entrada.
  */
  void leer();


  //Escritura de proceso

  /** @brief Operación de escritura

      \pre <em>cierto</em>
      \post Se han escrito los atributos del parámetro implícito en el canal
      standard de salida.
  */
  void escribir() const;
  /**@}*/

private:
  int identificador;
  int memoria;
  int tiempo;
  string prioridad;
};

#endif
