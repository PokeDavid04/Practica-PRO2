/** @file Procesador.hh
    @brief Especificación de la clase Procesador
*/

#ifndef _PROCESADOR_HH_
#define _PROCESADOR_HH_

// #ifndef NO_DIAGRAM
#include "Proceso.hh"
#include <list>
using namespace std;
// #endif

/** @class Procesador
    @brief Representa un procesador con un identificador, una cantidad de memoria y una lista con los procesos activos en la memoria

*/

class Procesador
{
public:
  //Constructoras
    /**
     * @name Constructoras
     * @{
    */

  /** @brief Creadora por defecto.

      Se ejecuta automáticamente al declarar un procesador.
      \pre <em>cierto</em>
      \post El resultado es un procesador sin identificador, sin cantidad de memoria ni procesos activos (lista vacía)
  */
  Procesador();

  /** @brief Creadora con valores concretos.

      \pre id un string de letras y dígitos, cmem>0
      \post El resultado es un procesador con identificador "id", cantidad de memoria "cmem" y sin procesos activos (lista vacía)
  */
  Procesador(string id, int cmem);
  /**@}*/



  //Modificadoras
  /**
     * @name Modificadoras
     * @{
    */

  /** @brief Modificadora de los procesos del atributo lista de procesos

      \pre <em>cierto</em>
      \post Avanza t unidades de tiempo en los procesos de la lista de procesos del parámetro implícito y elimina los procesos terminados (cuando su tiempo es igual a 0)
  */
  void avanzar_tiempo(int t);

  /** @brief Modificadora de los procesos del atributo lista de procesos

      Reordena los procesos por orden de llegada, lo mas a la izquierda posible y sin dejar huecos entre medio
      \pre <em>cierto</em>
      \post Reordena los procesos de la lista de procesos del parámetro implícito
  */
  void compactar_memoria();

/** @brief Modificadora del atributo de la lista de procesos

      \pre No hay ningún proceso p en la lista de procesos y p cabe en el procesador
      \post Añade p a la lista de procesos en el primer hueco disponible empezando por la izquierda
  */
  void añadir_proceso(Proceso &p);

/** @brief Modificadora del atributo de la lista de procesos

      \pre p se encuentra en la lista de procesos
      \post Elimina p de la lista de procesos
  */
  void eliminar_proceso(Proceso &p);

/** @brief Modificadora del atributo de la lista de procesos

      \pre p se encuentra en la lista de procesos
      \post Elimina el proceso de prioridad p de la lista de procesos
  */
  void eliminar_proceso_prioridad(string p);

/** @brief Modificadora del atributo de la lista de procesos

      \pre p se encuentra en la lista de procesos
      \post Elimina el proceso de identificador id de la lista de procesos
  */
  void eliminar_proceso_identificador(int id);
  /**@}*/



  //Consultoras
  /**
     * @name Consultoras
     * @{
    */

  /** @brief Consulta si existe un proceso

      \pre <em>cierto</em>
      \post El resultado es true si p se encuentra en la lista de procesos del parámetro implícito y false de lo contrario
  */
  bool existe_proceso(Proceso &p) const;

  /** @brief Consulta si existe un proceso con cierto identificador

      \pre <em>cierto</em>
      \post El resultado es true si se encuentra en la lista de procesos del parámetro implícito un proceso con identificador id y false de lo contrario
  */
  bool existe_proceso_identificador(int id) const;

  /** @brief Consulta si existe una prioridad

      \pre <em>cierto</em>
      \post El resultado es true si p es una prioridad de algun proceso que se encuentra en la lista de procesos del parámetro implícito y false de lo contrario
  */
  bool existe_prioridad(string p) const;

  /** @brief Consulta si cabe un proceso

      \pre <em>cierto</em>
      \post El resultado es true si p cabe en la lista de procesos del parámetro implícito y false de lo contrario
  */
  bool cabe_proceso(Proceso &p) const;

  /** @brief Consultora de los procesos con cierta prioridad

      \pre <em>cierto</em>
      \post El resultado es una lista con los procesos con prioridad p de la lista de procesos del parámetro implícito
  */
  list<Proceso> consul_procesos_prioridad(string p) const;

  /** @brief Consultora del identificador

      \pre <em>cierto</em>
      \post El resultado es el identificador del parámetro implícito
  */
  string consul_identificador() const;

  /** @brief Consultora de la cantidad de memoria

      \pre <em>cierto</em>
      \post El resultado es la cantidad de memoria del parámetro implícito
  */
  int consul_cantidad_memoria() const;

  /** @brief Consulta si tiene procesos

      \pre <em>cierto</em>
      \post El resultado es true si el parámetro implícito tiene procesos en ejecución y false de lo contrario
  */
  bool tiene_procesos() const;
  /**@}*/



  /**
     * @name Lectura y Escritura
     * @{
    */
  //Lectura de procesador

  /** @brief Operación de lectura

      \pre <em>cierto</em>
      \post Se han leido los atributos del parámetro implícito desde el canal
      standard de entrada.
  */
  void leer();


  //Escritura procesador

  /** @brief Operación de escritura

      \pre <em>cierto</em>
      \post Se han escrito los atributos del parámetro implícito en el canal
      standard de salida.
  */
  void escribir() const;
  /**@}*/

private:
  string identificador;
  int cmem;
  list<Proceso> memprocesos;
};

#endif
