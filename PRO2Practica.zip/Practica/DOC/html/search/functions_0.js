var searchData=
[
  ['areaprocesos_78',['AreaProcesos',['../classAreaProcesos.html#abf9a2fa8af3cd6cf063134059b313671',1,'AreaProcesos::AreaProcesos()'],['../classAreaProcesos.html#aa19dabe21e9b105e0c39c0e3aa3b5337',1,'AreaProcesos::AreaProcesos(int n, list&lt; string &gt; l)']]],
  ['avanzar_5ftiempo_79',['avanzar_tiempo',['../classCluster.html#a3b93301a46cfa8cadf8d0121e234c386',1,'Cluster::avanzar_tiempo()'],['../classProcesador.html#a91055a2cc9c3129051a762a9eb2a1f19',1,'Procesador::avanzar_tiempo()']]],
  ['avanzar_5funidad_5ftiempo_80',['avanzar_unidad_tiempo',['../classProceso.html#a439a18f280ea9099fc60ee97c6491ba1',1,'Proceso']]],
  ['añadir_5fcluster_81',['añadir_cluster',['../classCluster.html#a65e6c02345951e284c451136cc88a01c',1,'Cluster']]],
  ['añadir_5fprioridad_82',['añadir_prioridad',['../classAreaProcesos.html#a9f5e8411f36728fde44336af5562b041',1,'AreaProcesos']]],
  ['añadir_5fproceso_83',['añadir_proceso',['../classAreaProcesos.html#ac57c48b8b8bd65c92aa4536364ab53bd',1,'AreaProcesos::añadir_proceso()'],['../classCluster.html#ae3a37f77036fa80b9788f0b61c0d146e',1,'Cluster::añadir_proceso()'],['../classProcesador.html#a6176cba08cc72654d9243442c4e3450b',1,'Procesador::añadir_proceso()']]],
  ['añadir_5fproceso_5fprocesador_84',['añadir_proceso_procesador',['../classCluster.html#a82a305a98badbfd401dff9657eb9127f',1,'Cluster']]]
];
