var searchData=
[
  ['procesador_70',['Procesador',['../classProcesador.html',1,'']]],
  ['proceso_71',['Proceso',['../classProceso.html',1,'']]]
];
