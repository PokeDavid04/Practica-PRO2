var searchData=
[
  ['leer_110',['leer',['../classAreaProcesos.html#ada593073fe7bef4581cfe5cfb8c0eab6',1,'AreaProcesos::leer()'],['../classCluster.html#a482d879edb37f72e49c13e9c3e6c4320',1,'Cluster::leer()'],['../classProcesador.html#ac104960814ba918ba113ed9d58bca271',1,'Procesador::leer()'],['../classProceso.html#ad133f53bba77755f779ef63b6e529cdb',1,'Proceso::leer()']]],
  ['lista_5fprioridad_5fvacia_111',['lista_prioridad_vacia',['../classAreaProcesos.html#a47bc1c11497df75ba73579ea790f6afd',1,'AreaProcesos']]],
  ['lista_5fprocesos_5fvacia_112',['lista_procesos_vacia',['../classAreaProcesos.html#a9cffc261d55bfe0bf574a41a393f193b',1,'AreaProcesos']]]
];
