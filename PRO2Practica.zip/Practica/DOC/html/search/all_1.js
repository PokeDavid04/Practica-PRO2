var searchData=
[
  ['cabe_5fproceso_8',['cabe_proceso',['../classCluster.html#a0a7abc346f6d6985df4e1d20e815bc89',1,'Cluster::cabe_proceso()'],['../classProcesador.html#a980f33294d0572f4517f66d33f0da153',1,'Procesador::cabe_proceso()']]],
  ['cabe_5fproceso_5fprocesador_9',['cabe_proceso_procesador',['../classCluster.html#a15454c6fd367a5d4e687517569510967',1,'Cluster']]],
  ['cluster_10',['Cluster',['../classCluster.html#aee7feb1d599d4c8fda6c3ee83e86ba81',1,'Cluster::Cluster()'],['../classCluster.html',1,'Cluster']]],
  ['cluster_2ehh_11',['Cluster.hh',['../Cluster_8hh.html',1,'']]],
  ['compactar_5fmemoria_12',['compactar_memoria',['../classCluster.html#a622839c3b8dc923dc36f6026f35db269',1,'Cluster::compactar_memoria()'],['../classProcesador.html#a06b0b1c913b359a1bc6c920120dd0e66',1,'Procesador::compactar_memoria()']]],
  ['compactar_5fmemoria_5fprocesador_13',['compactar_memoria_procesador',['../classCluster.html#a2c9460fedf7bfc5963302c6e33d001fe',1,'Cluster']]],
  ['consul_5fcantidad_5fmemoria_14',['consul_cantidad_memoria',['../classProcesador.html#ab4f10cbc290a4031a0b8c7c75fe4671d',1,'Procesador']]],
  ['consul_5fidentificador_15',['consul_identificador',['../classProcesador.html#a02e834938974a0b33d4c0bd7799d6e39',1,'Procesador::consul_identificador()'],['../classProceso.html#a30c8302b163d93a24def32ed154937bf',1,'Proceso::consul_identificador() const']]],
  ['consul_5fmemoria_16',['consul_memoria',['../classProceso.html#aad4d01b21237cf5ffe32032a044b1853',1,'Proceso']]],
  ['consul_5fprioridad_17',['consul_prioridad',['../classProceso.html#a01880c9fdefc97681c755ee295859b48',1,'Proceso']]],
  ['consul_5fprocesador_18',['consul_procesador',['../classCluster.html#aa8ff796e4d95ca1032885b17b850514f',1,'Cluster']]],
  ['consul_5fprocesos_5fprioridad_19',['consul_procesos_prioridad',['../classAreaProcesos.html#afe14d8559fe4ca5999c49ef8b3de644b',1,'AreaProcesos::consul_procesos_prioridad()'],['../classCluster.html#a5bd262e784f2ce2efb5d9849266a9ab5',1,'Cluster::consul_procesos_prioridad()'],['../classProcesador.html#a0050845be44a3949c38486e178bf0d49',1,'Procesador::consul_procesos_prioridad()']]],
  ['consul_5ftiempo_20',['consul_tiempo',['../classProceso.html#aacd519894341a2f351f0a5af8a7931f6',1,'Proceso']]]
];
