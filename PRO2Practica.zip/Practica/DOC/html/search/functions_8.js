var searchData=
[
  ['tiene_5fprocesadores_5fauxiliares_117',['tiene_procesadores_auxiliares',['../classCluster.html#ab3a17271a09a302933d227ca75cce092',1,'Cluster']]],
  ['tiene_5fprocesos_118',['tiene_procesos',['../classProcesador.html#af43db3ddfe98258796650e07a8bec6e9',1,'Procesador']]]
];
