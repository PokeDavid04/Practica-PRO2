# Simulación del rendimiento de procesadores interconectados

Queremos simular el funcionamiento de una arquitectura multiprocesador, donde
cada procesador trabaja exclusivamente con su propia memoria y puede ejecutar más
de un proceso simultáneamente.

## Clases

Lista de clases creadas para el proyecto.

- Proceso
- Procesador
- Cluster
- AreaProcesos (Área de espera)

## Autor

David Berrocal Fidalgo

correo: david.berrocal.fidalgo@estudiantat.upc.edu



