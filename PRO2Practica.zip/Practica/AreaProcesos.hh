/** @file AreaProcesos.hh
    @brief Especificación de la clase Area de Procesos
*/

#ifndef _AREA_PROCESOS_HH_
#define _AREA_PROCESOS_HH_

// #ifndef NO_DIAGRAM
#include "Proceso.hh"
#include <list>
using namespace std;
// #endif

/** @class AreaProcesos
    @brief Representa un área de procesos con una lista de procesos ordenados de mayor a menor prioridad, un número de prioridades y una lista con las propiedades posibles ordenadas de mayor prioridad a menor

*/

class AreaProcesos
{
public:
  //Constructoras
    /**
     * @name Constructoras
     * @{
    */

  /** @brief Creadora por defecto.

      Se ejecuta automáticamente al declarar un área de procesos.
      \pre <em>cierto</em>
      \post El resultado es un área de procesos sin procesos, sin número de prioridades ni prioridades posibles
  */
  AreaProcesos();

  /** @brief Creadora con valores concretos.

      \pre n>0, tamaño de l = n
      \post El resultado es un área de procesos con n número de prioridades y l lista de prioridades posibles
  */
  AreaProcesos(int n, list<string> l);
  /**@}*/



  //Modificadoras
  /**
     * @name Modificadoras
     * @{
    */

  /** @brief Inicializa el área de procesos

      \pre El parámetro implícito no está inicializado
      \post El parámetro implícito pasa a estar inicializado con n número de prioridades y l lista de prioridades
  */
  void inicializar(int n, list<string> p);

  /** @brief Añade un proceso al área de procesos

      \pre No hay ningún proceso en la lista con el identificador y prioridad de p
      \post El parámetro implícito pasa a tener un proceso más en la lista de procesos, la lista sigue ordenada de mayor a menor prioridad
  */
  void añadir_proceso(Proceso &p);

  /** @brief Añade una prioridad al área de procesos

      \pre No hay ninguna prioridad igual a p en la lista
      \post El parámetro implícito pasa a tener una prioridad más en la lista de prioridades, el numero de prioridades se incrementa en uno, la lista sigue ordenada de mayor a menor prioridad
  */
  void añadir_prioridad(string p);

  /** @brief Elimina una prioridad del área de procesos

      \pre Hay ninguna prioridad igual a p en la lista
      \post El parámetro implícito pasa a no tener la prioridad p en la lista de prioridades, el numero de prioridades se decrementa en uno, la lista sigue ordenada de mayor a menor prioridad
  */
  void eliminar_prioridad(string p);

  /** @brief Elimina y devuelve el primer proceso del área de procesos

      \pre La lista de procesos no està vacía
      \post El parámetro implícito pasa a tener un proceso menos en la lista de procesos (el de más prioridad), la lista sigue ordenada de mayor a menor prioridad
  */
  Proceso sacar_primer_proceso();
  /**@}*/



  //Consultoras
  /**
     * @name Consultoras
     * @{
    */

  /** @brief Consulta si existe una prioridad

      \pre <em>cierto</em>
      \post El resultado es true si p se encuentra en la lista de prioridades del parámetro implícito y false de lo contrario
  */
  bool existe_prioridad(string p) const;

  /** @brief Consulta si existe un proceso

      \pre <em>cierto</em>
      \post El resultado es true si existe un proceso con identificador id en el paràmetro implícito y false de lo contrario
  */
  bool existe_proceso(int id) const;

  /** @brief Consulta si la lista de procesos está vacía

      \pre <em>cierto</em>
      \post El resultado es true si la lista de procesos del parámetro implícito está vacía y false de lo contrario
  */
  bool lista_procesos_vacia() const;

  /** @brief Consulta si la lista de prioridades está vacía

      \pre <em>cierto</em>
      \post El resultado es true si la lista de prioridades del parámetro implícito está vacía y false de lo contrario
  */
  bool lista_prioridad_vacia() const;

  /** @brief Consultora de los procesos con cierta prioridad

      \pre <em>cierto</em>
      \post El resultado es una lista con los procesos con prioridad p de la lista de procesos del parámetro implícito
  */
  list<Proceso> consul_procesos_prioridad(string p) const;
  /**@}*/



  /**
     * @name Lectura y Escritura
     * @{
    */
  //Lectura de área de procesos

  /** @brief Operación de lectura

      \pre <em>cierto</em>
      \post Se han leido los atributos del parámetro implícito desde el canal
      standard de entrada.
  */
  void leer();


  //Escritura de área de procesos

  /** @brief Operación de escritura

      \pre <em>cierto</em>
      \post Se han escrito los atributos del parámetro implícito en el canal
      standard de salida.
  */
  void escribir() const;
  /**@}*/

private:
  list<Proceso> listprocesos;
  int numprioridades;
  list<string> listprioridades;
};

#endif
