// #ifndef NO_DIAGRAM
#include "Proceso.hh"
#include "Procesador.hh"
#include "Cluster.hh"
#include "AreaProcesos.hh"
using namespace std;
// #endif

const string Error1 = "Error1: ";
const string Error2 = "Error2: ";
const string Error3 = "Error3: ";
const string Error4 = "Error4: ";
const string Error5 = "Error5: ";
const string Error6 = "Error6: ";
const string Error7 = "Error7: ";
const string Error8 = "Error8: ";
const string Error9 = "Error9: ";
const string Error10 = "Error10: ";
const string Error11 = "Error11: ";
const string Error12 = "Error12: ";
const string Error13 = "Error13: ";
const string Error14 = "Error14: ";
const string Error15 = "Error15: ";
const string Error16 = "Error16: ";
const string Error17 = "Error17: ";
const string Error18 = "Error18: ";
const string Error19 = "Error19: ";
const string Error20 = "Error20: ";

int main(){
    //inicializa un cluster
    Cluster c;

    //inicializa un area de procesos pendientes
    AreaProcesos area;
    int n;
    list<string> l;
    cin >> n;
    for(int i=0; i<n; ++i){
        string p;
        cin >> p;
        l.push_back(p);
    }
    area.inicializar(n, l);

    //lee comando
    string com;
    cin >> com;

    while(com != "fin"){
        //procesa comando
        if(com == "configurar_cluster" || com == "cc"){
            c.leer();
        }
        else if(com == "modificar_cluster" || com == "mc"){
            string p; cin >> p;
            Cluster c2; c2.leer();
            if(!c.existe_procesador(p)) cout << Error1 << endl;
            else{
                Procesador paux = c.consul_procesador(p);
                if(paux.tiene_procesos()) cout << Error2 << endl;
                else if(c.tiene_procesadores_auxiliares(p)) cout << Error3 << endl;
                else c.añadir_cluster(p, c2);
            }
        }
        else if(com == "alta_prioridad" || com == "ap"){
            string p; cin >> p;
            if(area.existe_prioridad(p)) cout << Error4 << endl;
            else area.añadir_prioridad(p);
        }
        else if(com == "baja_prioridad" || com == "bp"){
            string p; cin >> p;
            if(!area.existe_prioridad(p)) cout << Error5 << endl;
            else area.eliminar_prioridad(p);
        }
        else if(com == "alta_proceso_espera" || com == "ape"){
            Proceso pro; pro.leer();
            string prio; cin >> prio;
            if(!area.existe_prioridad(prio)) cout << Error6 << endl;
            else if(area.existe_proceso(pro.consul_identificador())) cout << Error7 << endl;
            else area.añadir_proceso(pro);
        }
        else if(com == "alta_proceso_procesador" || com == "app"){
            string id; cin >> id;
            Proceso p; p.leer();
            if(!c.existe_procesador(id)) cout << Error8 << endl;
            else{
                Procesador paux = c.consul_procesador(id);
                if(paux.existe_proceso_identificador(p.consul_identificador())) cout << Error9 << endl;
                else if(!paux.cabe_proceso(p)) cout << Error10 << endl;
                else c.añadir_proceso_procesador(id, p);
            }
        }
        else if(com == "baja_proceso_procesador" || com == "bpp"){

        }
        else if(com == "enviar_procesos_cluster" || com == "epc"){

        }
        else if(com == "avanzar_tiempo" || com == "at"){

        }
        else if(com == "imprimir_prioridad" || com == "ipri"){

        }
        else if(com == "imprimir_area_espera" || com == "iae"){

        }
        else if(com == "imprimir_procesador" || com == "ipro"){

        }
        else if(com == "imprimir_procesadores_cluster" || com == "ipc"){

        }
        else if(com == "imprimir_estructura_cluster" || com == "iec"){

        }
        else if(com == "compactar_memoria_procesador" || com == "cmp"){

        }
        else if(com == "compactar_memoria_cluster" || com == "cmc"){

        }
        //lee comando
        cin >> com;
    }

}
