var searchData=
[
  ['prioridad_110',['prioridad',['../classProceso.html#aff8cee23c84d54a64825ed158f1bd6d7',1,'Proceso']]],
  ['prioridad_5fvacia_111',['PRIORIDAD_VACIA',['../classProceso.html#a334f90ad37d2b25e8b580918d2a4d2f2',1,'Proceso']]],
  ['prioridades_112',['prioridades',['../classAreaProcesos.html#ada7f49a989d3fe3633423af5e28bcb1c',1,'AreaProcesos']]]
];
