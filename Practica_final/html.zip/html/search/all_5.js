var searchData=
[
  ['main_38',['main',['../program_8cc.html#ae66f6b31b5ad750f1fe042a706a4e3d4',1,'program.cc']]],
  ['mapprocesos_39',['mapprocesos',['../classProcesador.html#ada69a81c89b3729cd0aea020491d255a',1,'Procesador']]],
  ['memoria_40',['memoria',['../classProceso.html#ac37ccb93a804abd4b829ac7d4ad828bd',1,'Proceso']]],
  ['memprocesos_41',['memprocesos',['../classProcesador.html#a517a05d934d61414548e8587f97fb478',1,'Procesador']]]
];
