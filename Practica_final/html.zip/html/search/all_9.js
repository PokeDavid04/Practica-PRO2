var searchData=
[
  ['tiempo_54',['tiempo',['../classProceso.html#a23541aa8fe702c686a760c378a1b00d2',1,'Proceso']]],
  ['tiene_5fprocesos_55',['tiene_procesos',['../classProcesador.html#af43db3ddfe98258796650e07a8bec6e9',1,'Procesador']]]
];
