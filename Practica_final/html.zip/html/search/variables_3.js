var searchData=
[
  ['listprocesadores_105',['listprocesadores',['../classCluster.html#a81d024209879707da0ac88dc00c1e17d',1,'Cluster']]],
  ['listprocesos_106',['listprocesos',['../structAreaProcesos_1_1info__prioridad.html#a86cba975bf0448e86562e60b18c6dd91',1,'AreaProcesos::info_prioridad']]]
];
