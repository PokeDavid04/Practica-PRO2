var searchData=
[
  ['i_5fcopiar_5fcluster_91',['i_copiar_cluster',['../classCluster.html#a5d28094b3449c80943e4a12f5d13690e',1,'Cluster']]],
  ['i_5fescribir_5festructura_92',['i_escribir_estructura',['../classCluster.html#a142ea2f57a6e339b3437d094a033718f',1,'Cluster']]],
  ['i_5fleer_93',['i_leer',['../classCluster.html#a33d37571ecf1f30ada4f50768391a038',1,'Cluster']]]
];
