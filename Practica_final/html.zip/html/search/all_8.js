var searchData=
[
  ['sacar_5fprimer_5fproceso_52',['sacar_primer_proceso',['../classAreaProcesos.html#a5c527de1d93d9526f36344548f2c5f31',1,'AreaProcesos']]],
  ['simulación_20del_20rendimiento_20de_20procesadores_20interconectados_53',['Simulación del rendimiento de procesadores interconectados',['../index.html',1,'']]]
];
