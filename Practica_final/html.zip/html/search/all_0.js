var searchData=
[
  ['anadir_5fcluster_0',['anadir_cluster',['../classCluster.html#a12f24cb95fb75a36e578d0048d750c9c',1,'Cluster']]],
  ['anadir_5fprioridad_1',['anadir_prioridad',['../classAreaProcesos.html#aba3e96fa4a6e04212953489953d26465',1,'AreaProcesos']]],
  ['anadir_5fproceso_2',['anadir_proceso',['../classAreaProcesos.html#a338073745e2876daa2d2498b6b46d3e8',1,'AreaProcesos::anadir_proceso()'],['../classCluster.html#aadded4cfd62ed7401bbee43347364dcc',1,'Cluster::anadir_proceso()'],['../classProcesador.html#a50b759c30ef81c8d6b3643b3a6f46302',1,'Procesador::anadir_proceso()']]],
  ['anadir_5fproceso_5fprocesador_3',['anadir_proceso_procesador',['../classCluster.html#a0552343cd8c0d0e675ce95a6cf7ce17a',1,'Cluster']]],
  ['anadir_5fproceso_5frechazado_4',['anadir_proceso_rechazado',['../classAreaProcesos.html#a732f16138e7c69c45c1d99dbefa93f5f',1,'AreaProcesos']]],
  ['areaprocesos_5',['AreaProcesos',['../classAreaProcesos.html',1,'AreaProcesos'],['../classAreaProcesos.html#abf9a2fa8af3cd6cf063134059b313671',1,'AreaProcesos::AreaProcesos()']]],
  ['areaprocesos_2ehh_6',['AreaProcesos.hh',['../AreaProcesos_8hh.html',1,'']]],
  ['aumenta_5funidad_5fenviados_5fprioridad_7',['aumenta_unidad_enviados_prioridad',['../classAreaProcesos.html#aa16ec39f6dd626c8e01e8df035165cca',1,'AreaProcesos']]],
  ['avanzar_5ftiempo_8',['avanzar_tiempo',['../classCluster.html#a3b93301a46cfa8cadf8d0121e234c386',1,'Cluster::avanzar_tiempo()'],['../classProcesador.html#a91055a2cc9c3129051a762a9eb2a1f19',1,'Procesador::avanzar_tiempo()'],['../classProceso.html#aacfa317b627623ffde171bd0e1419ac8',1,'Proceso::avanzar_tiempo()']]]
];
