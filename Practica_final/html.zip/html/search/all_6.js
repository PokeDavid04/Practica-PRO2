var searchData=
[
  ['pagprinc_2emd_42',['PAGPRINC.md',['../PAGPRINC_8md.html',1,'']]],
  ['prioridad_43',['prioridad',['../classProceso.html#aff8cee23c84d54a64825ed158f1bd6d7',1,'Proceso']]],
  ['prioridad_5fvacia_44',['PRIORIDAD_VACIA',['../classProceso.html#a334f90ad37d2b25e8b580918d2a4d2f2',1,'Proceso']]],
  ['prioridades_45',['prioridades',['../classAreaProcesos.html#ada7f49a989d3fe3633423af5e28bcb1c',1,'AreaProcesos']]],
  ['procesador_46',['Procesador',['../classProcesador.html',1,'Procesador'],['../classProcesador.html#aacfa2a06c7d44636ecfb0338bebbfa8b',1,'Procesador::Procesador()'],['../classProcesador.html#a23bd738c44774499b8d5287ebea8f452',1,'Procesador::Procesador(string id, int cmem)']]],
  ['procesador_2ehh_47',['Procesador.hh',['../Procesador_8hh.html',1,'']]],
  ['proceso_48',['Proceso',['../classProceso.html',1,'Proceso'],['../classProceso.html#a632f57d6ec48e76c80fbeb7734c1148c',1,'Proceso::Proceso()'],['../classProceso.html#a50f82929a5a5b55fb84959fd65b97c23',1,'Proceso::Proceso(int id, int cmem, int t, string p)'],['../classProceso.html#ab3f6a863fac8c441b1cdc5d7bd06d937',1,'Proceso::Proceso(int cmem)']]],
  ['proceso_2ehh_49',['Proceso.hh',['../Proceso_8hh.html',1,'']]],
  ['program_2ecc_50',['program.cc',['../program_8cc.html',1,'']]]
];
